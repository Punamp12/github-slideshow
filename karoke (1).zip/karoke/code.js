onEvent("button23", "click", function(event) {
  playSound("assets/category_app/app_button_5.mp3", false);
});
onEvent("button10", "click", function( tn) {
  playSound("assets/category_app/app_button_5.mp3", false);
});
onEvent("button1", "click", function(n ) {
  playSound("assets/category_music/birthday_kazoo_negative_game_cue_1.mp3", false);
});
